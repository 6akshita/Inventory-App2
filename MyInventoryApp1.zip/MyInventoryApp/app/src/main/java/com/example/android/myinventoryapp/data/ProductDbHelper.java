package com.example.android.myinventoryapp.data;

/**
 * Created by akshita on 16/5/17.
 */

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import static java.sql.Types.BLOB;

public class ProductDbHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 2;
    public static final String DATABASE_NAME = "Inventory.db";

    public ProductDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

         String SQL_CREATE_PRODUCTS_TABLE =
                "CREATE TABLE " + ProductContract.ProductEntry.TABLE_NAME + " ( " +
                        ProductContract.ProductEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                        ProductContract.ProductEntry.COLUMN_PRODUCT_NAME + " TEXT NOT NULL " + "," +
                        ProductContract.ProductEntry.COLUMN_PRODUCT_QUANTITY + " INTEGER NOT NULL DEFAULT 0 " + "," +
                        ProductContract.ProductEntry.COLUMN_PRODUCT_PRICE + " REAL NOT NULL DEFAULT 0.00 " + "," +
                        ProductContract.ProductEntry.COLUMN_EMAIL + " TEXT NOT NULL " + "," +
                        ProductContract.ProductEntry.COLUMN_PRODUCT_IMAGE + " BLOB NOT NULL "+
                        ");";

        db.execSQL(SQL_CREATE_PRODUCTS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

         String SQL_DELETE_PRODUCTS_TABLE = "DROP TABLE IF EXISTS " + ProductContract.ProductEntry.TABLE_NAME;

        if( oldVersion != newVersion) {
            db.execSQL(SQL_DELETE_PRODUCTS_TABLE);
            onCreate(db);
        }
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }
}