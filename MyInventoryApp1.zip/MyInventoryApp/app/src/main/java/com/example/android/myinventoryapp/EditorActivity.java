package com.example.android.myinventoryapp;

/**
 * Created by akshita on 16/5/17.
 */

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.v4.app.LoaderManager;
import android.support.v4.app.NavUtils;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.method.DigitsKeyListener;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.android.myinventoryapp.data.ProductContract;
import com.example.android.myinventoryapp.data.ProductContract.ProductEntry;

import java.io.ByteArrayOutputStream;
public class EditorActivity extends AppCompatActivity{
    public static final String LOG_TAG = EditorActivity.class.getName();

    private static final int PRODUCT_LOADER = 1;
    private static final int FILE_SELECT_CODE = 1;
    private Uri mCurrentProductUri;

    EditText mName;
    EditText mQuantity;
    EditText mPrice;
    EditText mEmail;
    Button mImageButton;
    ImageView mImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);

        mName = (EditText) findViewById(R.id.edit_text_product_name);
        mQuantity = (EditText) findViewById(R.id.edit_text_product_count);
        mPrice = (EditText) findViewById(R.id.edit_text_product_price);
        mEmail = (EditText) findViewById(R.id.edit_text_email);
        mImageButton = (Button) findViewById(R.id.product_image);
        mImageView = (ImageView) findViewById(R.id.image_view);


        mImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buttonImageClick();
            }
        });

        mPrice.setFilters(new InputFilter[] {
                new DigitsKeyListener(Boolean.FALSE, Boolean.TRUE) {
                    int beforeDecimal = 5, afterDecimal = 2;

                    @Override
                    public CharSequence filter(CharSequence source, int start, int end,
                                               Spanned dest, int dstart, int dend) {
                        String temp = mPrice.getText() + source.toString();

                        if (temp.equals(".")) {
                            return "0.";
                        }
                        else if (temp.toString().indexOf(".") == -1) {
                            // no decimal point placed yet
                            if (temp.length() > beforeDecimal) {
                                return "";
                            }
                        } else {
                            temp = temp.substring(temp.indexOf(".") + 1);
                            if (temp.length() > afterDecimal) {
                                return "";
                            }
                        }

                        return super.filter(source, start, end, dest, dstart, dend);
                    }
                }
        });

        Intent intent = getIntent();
        mCurrentProductUri = intent.getData();

        if(mCurrentProductUri == null) {
            setTitle(R.string.editor_title_add);
        }
    }

    private void buttonImageClick() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), FILE_SELECT_CODE);
    }


    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == FILE_SELECT_CODE && resultCode == RESULT_OK) {
                try {
                    Bundle extras = data.getExtras();
                    Bitmap bitmap = (Bitmap) extras.get("data");

               //     Uri imageUri = data.getData();
                 //   Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);

                    mImageView = (ImageView) findViewById(R.id.image_view);
                    mImageView.setImageBitmap(bitmap);

                } catch (Exception exp ){
                    Log.e(LOG_TAG,"exception "+exp);
        //            exp.printStackTrace();

            }
        }
    }

  /*  protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data!=null) {
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");

            ImageView testImage = (ImageView) findViewById(R.id.add_image_edit);
            testImage.setImageBitmap(imageBitmap);

            // Convert Bitmap to byte array
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            imageBitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
            image = stream.toByteArray();
        }
    }
*/

    private void saveProduct() {
        String name = mName.getText().toString().trim();
        String quantity = mQuantity.getText().toString().trim();
        String price = mPrice.getText().toString().trim();
        String email = mEmail.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(quantity) || TextUtils.isEmpty(price) ||TextUtils.isEmpty(email)) {
            Toast.makeText(this,"Please fill out all values", Toast.LENGTH_SHORT).show();
            return;
        }

        int quant = Integer.valueOf(quantity);
        double price1 = Double.valueOf(price);

        if(quant < 0) {
            Toast.makeText(this,"Please input a real number for the quantity field.", Toast.LENGTH_SHORT).show();
            return;
        }

        if(price1 < 0.0) {
            Toast.makeText(this,"Please input a real price.", Toast.LENGTH_SHORT).show();
            return;
        }

        if(mImageView.getDrawable() == null) {
            Toast.makeText(this,"Please upload an image.", Toast.LENGTH_SHORT).show();
            return;
        }

        Bitmap imageBitMap = ((BitmapDrawable)mImageView.getDrawable()).getBitmap();
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        imageBitMap.compress(Bitmap.CompressFormat.PNG, 100, bos);
        byte[] imageByteArray = bos.toByteArray();




 /*       protected void onActivityResult(int requestCode, int resultCode, Intent data) {

            if (requestCode == REQUEST_IMAGE && resultCode == RESULT_OK && data!=null) {
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");

                ImageView testImage = (ImageView) findViewById(R.id.add_image_edit);
                testImage.setImageBitmap(imageBitmap);

                // Convert Bitmap to byte array
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                imageBitmap.compress(Bitmap.CompressFormat.PNG, 0, stream);
                image = stream.toByteArray();
            }
        }

*/

        ContentValues values = new ContentValues();
        values.put(ProductEntry.COLUMN_PRODUCT_NAME, name);
        values.put(ProductEntry.COLUMN_PRODUCT_QUANTITY, quant);
        values.put(ProductEntry.COLUMN_PRODUCT_PRICE, price1);
        values.put(ProductEntry.COLUMN_EMAIL, email);
        values.put(ProductEntry.COLUMN_PRODUCT_IMAGE, imageByteArray);

        Uri newUri = getContentResolver().insert(ProductEntry.CONTENT_URI, values);

        if (newUri == null) {
            Toast.makeText(this, getString(R.string.editor_insert_failed), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(this, getString(R.string.editor_insert_successful), Toast.LENGTH_LONG).show();
            finish();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_editor, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_save:
                saveProduct();
                return true;
            case android.R.id.home:
                NavUtils.navigateUpFromSameTask(EditorActivity.this);
                return true;
        }
        return super.onOptionsItemSelected(item);
    }
}